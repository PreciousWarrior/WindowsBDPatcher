const Module = require("module");
const path = require("path");
const fs = require("fs");
const electron = require("electron");
const ipc = electron.ipcRenderer;
const config = require("./config");
const Logger = require("./logger");

// const context = electron.webFrame.top.context;
electron.webFrame.top.context.require = require;
electron.webFrame.top.context.process = process;
// electron.webFrame.top.context.setTimeout = setTimeout;
// electron.webFrame.top.context.setInterval = setInterval;
// electron.webFrame.top.context.setImmediate = setImmediate;

// global.setTimeout = setTimeout;
// global.setInterval = setInterval;
// global.setImmediate = setImmediate;
// context.process = {platform: process.platform, env: process.env};

// Define script injector
// const injectScript = url => new Promise(resolve => {
//     const script = context.document.createElement("script");
//     script.type = "text/javascript";
//     script.onload = () => resolve(true);
//     script.onerror = () => resolve(false);
//     script.src = url;
//     context.document.body.appendChild(script);
// });

// const testJSON = function(data) {
//     try {return JSON.parse(data);}
//     catch (error) {return false;}
// };

// const getFile = async function(url) {
//     return await context.fetch(url,{
//         method: "GET",
//         credentials: "include",
//         mode: "cors",
//         headers: {
//             "Accept": "application/json",
//             "Content-Type": "application/json",
//             "User-Agent": "BetterDiscord"
//         }
//     });
//     // return new Promise(resolve => {
//     //     request.get(url, function(error, response, body) {
//     //         if (error || response.statusCode !== 200) return resolve(null);
//     //         resolve(body);
//     //     });
//     // });
// };

// const getCommitHash = async function(branch = "gh-pages") {
//     const url = `https://api.github.com/repos/rauenzi/BetterDiscordApp/commits/${branch}`;
//     Logger.log("Getting hash from: " + url);
//     const data = await getFile(url);
//     const parsed = testJSON(data);
//     if (!parsed) return null;
//     return parsed.sha;
// };

// const loadResource = async function(base, backup, injector) {
//     Logger.log(`Loading Resource (${base})`);
//     let success = await injector(base);
//     if (success) return Logger.log(`Successfully loaded (${base})`);
//     Logger.warn(`Could not load ${base}. Using backup ${backup}`);
//     success = await injector(backup);
//     if (success) return Logger.log(`Successfully loaded (${backup})`);
//     Logger.err(`Could not load backup ${backup}. Giving up.`);
// };

// Load Discord's original preload
const preload = ipc.sendSync("GET_PRELOAD");
if (preload) {
    
    // Restore original preload for future windows
    process.electronBinding("command_line").appendSwitch("preload", preload);
    
    // Run original preload
    // const originalProcessOn = process.on;
    // process.on = () => {};
    try {require(preload);}
    catch (e) {}
    // process.on = originalProcessOn;
}

Module.globalPaths.push(path.resolve(ipc.sendSync("GET_APP_PATH"), "..", "app.asar", "node_modules"));

// Setup in renderer context
// const currentWindow = electron.remote.getCurrentWindow();
ipc.on("DOM_READY", async () => {

    console.log("DOM READY");

    // Get remote hash
    const hash = await ipc.invoke("GET_HASH", config.branch);
    console.log(hash);
    console.log(config);
    Object.assign(config, {hash});
    fs.writeFileSync(__dirname + "/config.json", JSON.stringify(config, null, 4));

    // while (!context.webpackJsonp || context.webpackJsonp.flat().flat().length <= 5000) {
    //     console.log(context.webpackJsonp.flat().flat());
    //     await new Promise(r => setTimeout(r, 100));
    // }

    if (config.local) {
        const localRemote = path.resolve(__dirname, "remote.js");
        Logger.log(`Loading Local Remote (${localRemote})`);
        const content = await new Promise (r => fs.readFile(localRemote, (e, b) => {
			if (e || !b) return r("");
			else return r(b);
		}));
		if (content) return ipc.invoke("EXEC_JS", content.toString());
		else Logger.error(`Failed loading Local Remote (${localRemote})`);
        // return;
    }
    // const hash = "master";
    // const baseUrl = `//cdn.staticaly.com/gh/rauenzi/BetterDiscordApp/${hash}/dist/remote.js`;
    // const backupUrl = "https://rauenzi.github.io/BetterDiscordApp/dist/remote.js";
    // await loadResource(baseUrl, backupUrl, injectScript);
});

