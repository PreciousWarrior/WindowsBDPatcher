const path = require("path");
const electron = require("electron");
const Logger = require("./betterdiscord/logger");
const Module = require("module");
const BetterDiscord = require("./betterdiscord");
process.env["NODE_OPTIONS"] = '--no-force-async-hooks-checks';
electron.app.commandLine.appendSwitch("no-force-async-hooks-checks");
process.electronBinding("command_line").appendSwitch("no-force-async-hooks-checks");

Module.globalPaths.push(path.resolve(electron.app.getAppPath(), "..", "app.asar", "node_modules"));

class BrowserWindow extends electron.BrowserWindow {
    constructor(options) {
        if (!options || !options.webPreferences || !options.webPreferences.preload || !options.title) return super(options); // eslint-disable-line constructor-super
        const originalPreload = options.webPreferences.preload;
        options.webPreferences.preload = path.join(__dirname, "betterdiscord", "preload.js");

        // Object.assign(options, BetterDiscord.getWindowPrefs()); // Assign new style window prefs if they exist

        // // Don't allow just "truthy" values
        // const shouldBeTransparent = BetterDiscord.getSetting("transparency");
        // if (typeof(shouldBeTransparent) === "boolean" && shouldBeTransparent) {
        //     options.transparent = true;
        //     options.backgroundColor = "#00000000";
        // }

        // // Only affect frame if it is *explicitly* set
        // const shouldHaveFrame = BetterDiscord.getSetting("frame");
        // if (typeof(shouldHaveFrame) === "boolean") options.frame = shouldHaveFrame;

        super(options);
        this.webContents.__originalPreload = originalPreload;

        this.webContents.on("dom-ready", () => {
            console.log("MAIN DOM READY");
            this.webContents.send("DOM_READY");
        });
    }
}

const testJSON = function(data) {
    try {return JSON.parse(data);}
    catch (error) {return false;}
};

const getFile = function(url) {
    const request = require("request").defaults({headers: {"User-Agent": "BetterDiscord"}});
    return new Promise(resolve => {
        request.get(url, function(error, response, body) {
            if (error || response.statusCode !== 200) return resolve(null);
            resolve(body);
        });
    });
};

const getCommitHash = async function(branch = "gh-pages") {
    const url = `https://api.github.com/repos/rauenzi/BetterDiscordApp/commits/${branch}`;
    Logger.log("Getting hash from: " + url);
    const data = await getFile(url);
    const parsed = testJSON(data);
    if (!parsed) return null;
    return parsed.sha;
};

const ipcMain = electron.ipcMain;
ipcMain.on("GET_PRELOAD", e => e.returnValue = e.sender.__originalPreload);
ipcMain.on("GET_APP_PATH", e => e.returnValue = electron.app.getAppPath());
ipcMain.on("RELAUNCH", () => {
    electron.app.quit();
    electron.app.relaunch();
});
ipcMain.handle("GET_HASH", async (event, branch) => {
    return await getCommitHash(branch);
});
ipcMain.handle("EXEC_JS", async (event, script) => {
    // console.log(script);
    try {
        await event.sender.executeJavaScript(`try {${script}} catch {}`);
    }
    catch (e) {}
    // console.log(result);
    // return result;
});

// Reassign electron using proxy to avoid the onReady issue, thanks Powercord!
const newElectron = new Proxy(electron, {
    get: function(target, prop) {
        if (prop === "BrowserWindow") return BrowserWindow;
        return target[prop];
    }
});
const electronPath = require.resolve("electron");
delete require.cache[electronPath].exports; // If it didn't work, try to delete existing
require.cache[electronPath].exports = newElectron; // Try to assign again after deleting

// Remove the CSP
const removeCSP = () => {
    electron.session.defaultSession.webRequest.onHeadersReceived(function(details, callback) {
        if (!details.responseHeaders["content-security-policy-report-only"] && !details.responseHeaders["content-security-policy"]) return callback({cancel: false});
        delete details.responseHeaders["content-security-policy-report-only"];
        delete details.responseHeaders["content-security-policy"];
        callback({cancel: false, responseHeaders: details.responseHeaders});
    });   
};

// Remove CSP immediately on linux since they install to discord_desktop_core still
if (process.platform == "win32" || process.platform == "darwin") electron.app.once("ready", removeCSP);
else removeCSP();

// electron.crashReporter.start({
//     productName: 'BetterDiscord',
//     companyName: 'betterdiscord',
//     submitURL: 'https://submit.backtrace.io/betterdiscord/45c462f2fa6cb9c4da3f420df9032f72604066478a24c8fed8ca50fe27ec125d/minidump',
//     uploadToServer: true,
//   });

// Use Discord's info to run the app
if (process.platform == "win32" || process.platform == "darwin") {
    const basePath = path.join(electron.app.getAppPath(), "..", "app.asar");
    const pkg = require(path.join(basePath, "package.json"));
    electron.app.setAppPath(basePath);
    electron.app.name = pkg.name;
    Module._load(path.join(basePath, pkg.main), null, true);
}

