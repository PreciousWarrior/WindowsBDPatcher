# BetterDiscord Injector

You're probably looking for the main app, [click here](https://github.com/rauenzi/BetterDiscordApp) to go there.